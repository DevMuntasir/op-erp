import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { LoginPage } from '@/src/features/auth/LoginPage';
import { InvitePage } from '@/src/features/auth/InvitePage';
import { ProtectedRoute, RootRedirect } from '@/src/features/auth/route-guards';
import { AppLayout } from '@/src/components/AdminLayout';
import { DashboardOverview } from '@/src/components/DashboardOverview';
import { ProfilePage } from '@/src/components/ProfilePage';
import { EmployeeManagement } from '@/src/features/employees/EmployeeManagement';
import { TaskManagement } from '@/src/components/TaskManagement';
import { TaskDetail } from '@/src/components/TaskDetail';
import { ClientManagement } from '@/src/components/ClientManagement';
import { ClientPortal } from '@/src/components/ClientPortal';
import { EmployeeDetail } from '@/src/components/EmployeeDetail';
import { SessionHistory } from '@/src/components/SessionHistory';
import { AdminScreenshots } from '@/src/components/AdminScreenshots';
import { ReportGenerator } from '@/src/components/ReportGenerator';
import BillingManagement from '@/src/components/BillingManagement';
import { LeadManagement } from '@/src/components/LeadManagement';
import { LeadFinder } from '@/src/components/LeadFinder';
import { ProposalDashboard } from '@/src/components/ProposalDashboard';
import { ProposalManagement } from '@/src/components/ProposalManagement';
import { SmartProposalBuilder } from '@/src/components/SmartProposalBuilder';
import { ProposalPreview } from '@/src/components/ProposalPreview';
import { ChatSystem } from '@/src/components/ChatSystem';
import { CallHistory } from '@/src/components/CallHistory';

function AdminArea() {
  return (
    <AppLayout role="admin">
      <Routes>
        <Route index element={<DashboardOverview />} />
        <Route path="employees" element={<EmployeeManagement />} />
        <Route path="employees/:employeeId" element={<EmployeeDetail />} />
        <Route path="tasks" element={<TaskManagement />} />
        <Route path="tasks/:taskId" element={<TaskDetail />} />
        <Route path="clients" element={<ClientManagement />} />
        <Route path="history" element={<SessionHistory />} />
        <Route path="monitoring" element={<AdminScreenshots />} />
        <Route path="reports" element={<ReportGenerator />} />
        <Route path="billing" element={<BillingManagement />} />
        <Route path="leads" element={<LeadManagement />} />
        <Route path="finder" element={<LeadFinder />} />
        <Route path="proposals" element={<ProposalDashboard />} />
        <Route path="proposals/all" element={<ProposalManagement />} />
        <Route path="proposals/new" element={<SmartProposalBuilder />} />
        <Route path="proposals/smart-builder" element={<SmartProposalBuilder />} />
        <Route path="proposals/edit/:id" element={<SmartProposalBuilder />} />
        <Route path="proposals/preview/:id" element={<ProposalPreview />} />
        <Route path="messages" element={<ChatSystem />} />
        <Route path="calls" element={<CallHistory />} />
        <Route path="profile" element={<ProfilePage />} />
      </Routes>
    </AppLayout>
  );
}

function EmployeeArea() {
  return (
    <AppLayout role="employee">
      <Routes>
        <Route index element={<DashboardOverview />} />
        <Route path="tasks" element={<TaskManagement />} />
        <Route path="tasks/:taskId" element={<TaskDetail />} />
        <Route path="clients" element={<ClientManagement />} />
        <Route path="history" element={<SessionHistory />} />
        <Route path="reports" element={<ReportGenerator />} />
        <Route path="leads" element={<LeadManagement />} />
        <Route path="finder" element={<LeadFinder />} />
        <Route path="proposals" element={<ProposalDashboard />} />
        <Route path="proposals/all" element={<ProposalManagement />} />
        <Route path="proposals/new" element={<SmartProposalBuilder />} />
        <Route path="proposals/smart-builder" element={<SmartProposalBuilder />} />
        <Route path="proposals/edit/:id" element={<SmartProposalBuilder />} />
        <Route path="proposals/preview/:id" element={<ProposalPreview />} />
        <Route path="messages" element={<ChatSystem />} />
        <Route path="calls" element={<CallHistory />} />
        <Route path="profile" element={<ProfilePage />} />
      </Routes>
    </AppLayout>
  );
}

export function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/invite/:token" element={<InvitePage />} />
        <Route element={<ProtectedRoute roles={['super_admin', 'admin']} />}>
          <Route path="/admin/*" element={<AdminArea />} />
        </Route>
        <Route element={<ProtectedRoute roles={['employee']} />}>
          <Route path="/employee/*" element={<EmployeeArea />} />
        </Route>
        <Route element={<ProtectedRoute roles={['client', 'admin', 'super_admin']} />}>
          <Route path="/client/*" element={<ClientPortal />} />
        </Route>
        <Route path="/" element={<RootRedirect />} />
      </Routes>
    </BrowserRouter>
  );
}
