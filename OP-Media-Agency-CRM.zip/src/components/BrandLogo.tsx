import React from 'react';
import { cn } from '../lib/utils';

interface LogoProps {
  className?: string;
  showText?: boolean;
  variant?: 'default' | 'white' | 'dark';
}

export const BrandLogo: React.FC<LogoProps> = ({ 
  className = "w-32 md:w-54", 
}) => {
  const logoUrl = "/api/proxy-image?url=https://www.opmediaagency.com/wp-content/uploads/2025/03/OP-Media-Logo3.png";

  return (
    <div className={cn("flex items-center mx-auto transition-all duration-300 shrink-0", className)}>
      <img 
        src={logoUrl} 
        alt="OP Media Agency" 
        crossOrigin="anonymous"
        referrerPolicy="no-referrer"
        className="max-w-full max-h-full object-contain"
      />
    </div>
  );
};
